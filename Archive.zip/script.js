
let lastScrollTop = 0; // Variable pour stocker la position précédente du scroll

function myFunction(el) {
  const currentSize = parseFloat(el.width); // Assurez-vous d'accéder à la propriété style.width
  const st = window.pageYOffset || document.documentElement.scrollTop; 

  let newWidth = currentSize;

  if (st > lastScrollTop) {
    // Scroll vers le bas
    newWidth = currentSize - 5;
    if (newWidth <= 95) {
      logo.style.transform = 'translateY(0px)';
    }

  } else {
    // Scroll vers le haut
    newWidth = currentSize + 5;
    if (newWidth >= 295) {
      logo.style.transform = 'translateY(100px)';
    }
  }

  // Assurer que la largeur reste entre 200px et 500px
  newWidth = Math.max(100, Math.min(300, newWidth));

  el.style.width = `${newWidth}px`;
  lastScrollTop = st <= 0 ? 0 : st;
}
